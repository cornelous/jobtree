jQuery(function(){
	jQuery( '.job-manager-category-dropdown' ).chosen();
});